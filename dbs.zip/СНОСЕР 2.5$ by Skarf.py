import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import time
import colored
from colored import cprint

senders = {
'ugtnddpzej@rambler.ru':'9506681adi6MU',
'cisvzeeuyg@rambler.ru':'6301453fJo4s9',
'ggflngvlih@rambler.ru':'22408953S2gby',
'nvynpxnkkd@rambler.ru':'2510571xHHdgR',
'fjzoyuouuz@rambler.ru':'59097784rDPPd',
'bzgqlptwhl@rambler.ru':'0816705Tr1FYG',
'vigzkazhat@rambler.ru':'31932120MtFlm',
'afgunihnfe@rambler.ru':'9061194g5B45C',
'ngvxtwpesz@rambler.ru':'2011142rqGxFR',
'egvwsdlkyr@rambler.ru':'9037151L6w49u',
'tfdmxqejns@rambler.ru':'7787340bbA3sL',
'thrcxqfhxt@rambler.ru':'4033354R50aaM',
'gzbsslvpgb@rambler.ru':'8608390st77PG',
'vgwkozobgf@rambler.ru':'0713430AUe0Jj',
'xthokzcxta@rambler.ru':'0362278TxeHl1',
'ulgtgyesux@rambler.ru':'4621758slMQ2q',
'mekpwikznr@rambler.ru':'3416279IFmuKQ',
'clgplzxnqw@rambler.ru':'6412121gc7Dcu',
'azfingoovg@rambler.ru':'6148697BuRbwO',
'xfjhvzmnac@rambler.ru':'9670930pBIR7W',
'thgwrxhltj@rambler.ru':'2369423cUvLuf',
'agpjaemyqm@rambler.ru':'6572399A8cFh6',
'wvicwdopps@rambler.ru':'7661495MeRn88',
'kpuaeogels@rambler.ru':'02848019U4yxH',
'dzdhnhsfia@rambler.ru':'6976310gzYoE2',
'vlldcxigrj@rambler.ru':'9022806maOtUs',
'hlfczgnfrr@rambler.ru':'9916462168Ypp',
'jtmtruwscg@rambler.ru':'9923365hkHeN6',
'aozzmmsvvi@rambler.ru':'0399945jLmU7B',
'nglqkjipix@rambler.ru':'0058167GPjOZR',
'dxldwtdips@rambler.ru':'4221180vuJqsB',
'fnymojqdux@rambler.ru':'4820302GP03Ru',
'elvyorfunb@rambler.ru':'9023694jkXJV4',
'yiredoekax@rambler.ru':'3543487Cm2P2a',
'hpobxpntkg@rambler.ru':'9360288IzyHkP',
'owbsixedjj@rambler.ru':'6443042VnSBeS',
'hgwptrmpwz@rambler.ru':'9923510OpfY1W',
'cyblanwvop@rambler.ru':'5825453FKm1ZE',
'uwtjezecrs@rambler.ru':'6411755QBcF7p',
'ybjbggdruu@rambler.ru':'4065298o86MLm',
'uckmapemvh@rambler.ru':'9531228JLg96F',
'jkjportalx@rambler.ru':'2401077inLnJj',
'kolnanjvkw@rambler.ru':'86294929rsQvg',
'rhzlhaagsc@rambler.ru':'03837749f9qvW',
'fdroghhuoy@rambler.ru':'13627259IrATl',
'jhripippie@rambler.ru':'8596550xkdTvR',
'fwczlkjeqx@rambler.ru':'6138606ClwDQY',
'ltgepfikkf@rambler.ru':'9196678SqSrNo',
'rseboxipnu@rambler.ru':'5273881rI53Q4',
'csrrduvhva@rambler.ru':'0197098oKVcgl',
'rnronnawvy@rambler.ru':'5904151bLInb3',
'rizztpwxyd@rambler.ru':'2987451FcdS9W',
'lpkooejmvn@rambler.ru':'60126542fjqTr',
'cvqhekksqc@rambler.ru':'9797778IDBtEB',
'pjqcttofdo@rambler.ru':'2388998PnjxXu',
'wgcopmhxgh@rambler.ru':'9358453IMyU8y',
'opaquxfpts@rambler.ru':'7561482OZeKI4',
'eaadnycsts@rambler.ru':'6416827JHSDrt',
'laonvtjfel@rambler.ru':'7560427uY24i2',
'xnhmnupwzr@rambler.ru':'0051569GHG6u5',
'shwnuhgqqg@rambler.ru':'4351266KnZn4V',
'dyiujjtnew@rambler.ru':'3980109iwPLPY',
'iwqjkfelvu@rambler.ru':'4863666lH6V3F',
'zthjgxtrpg@rambler.ru':'8369557WxoHo7',
'ojqtyvwncq@rambler.ru':'7256338Mv7n3t',
'hjnsizlgrm@rambler.ru':'8110884EZeyQN',
'kahzgsmkmt@rambler.ru':'0671533VIPWwu',
'kkrcdhrrlo@rambler.ru':'3389329h61aBP',
'sfeqfkurdt@rambler.ru':'2925887SxhsLr',
'ofaqyrsvuh@rambler.ru':'8560532Y4y9ST',
'dauzyaogpz@rambler.ru':'7525890u5k6fY',
'lpxahsdzse@rambler.ru':'8786157vOA06e',
'wwfhbxmsok@rambler.ru':'7143633fR8nVD',
'mwcgsgjfuk@rambler.ru':'6217831LCupHU',
'tjvramifwa@rambler.ru':'2757277idtpdI',
'mnglvhevjd@rambler.ru':'16070642NbiNv',
'fmyuigwxzb@rambler.ru':'02393808PjTDl',
'eyoadncsuz@rambler.ru':'9508621ADxNXJ',
'rjwzqnmtym@rambler.ru':'10304919ONiwi',
'kjjxdenroa@rambler.ru':'1945719Pd1KpX',
'qizipqicyk@rambler.ru':'75748031V2Yvq',
'psdapkcwlo@rambler.ru':'0738153oxxK6l',
'yivgugcrmv@rambler.ru':'0717090HGXo4m',
'rfmntxpdli@rambler.ru':'7475026YLuOVd',
'jzyhkqzrwg@rambler.ru':'32829246ADDDy',
'hsgcxbjpmw@rambler.ru':'5925366KieMqr',
'onvubjifqd@rambler.ru':'8025909RO2wjU',
'yojdtnotoh@rambler.ru':'3778117YQ5icX',
'dppeqqtnid@rambler.ru':'5383257QEzNWG',
'mmzlvrmnja@rambler.ru':'7097422ifCSZU',
'ynzxuwcogt@rambler.ru':'3439942j0bDR6',
'jzyteqvijn@rambler.ru':'4350877lnGya2',
'vhzjmmtlaa@rambler.ru':'0364214JbqVTT',
'fgfjxwridh@rambler.ru':'25963867kQxJ5',
'szyumzwsne@rambler.ru':'0663226qHamTE',
'lqrvzdoczi@rambler.ru':'00480808p6BGZ',
'ozaorfdyvy@rambler.ru':'8080035QpzthE',
'cckkcithvw@rambler.ru':'8084572djPEZt',
'ijnlscnubk@rambler.ru':'7096542Eu1BrB',
'ontxnfpjxg@rambler.ru':'9866476ZvOowy',
'ysnhvdfcvb@rambler.ru':'9032549xeTYnL',
'rsjhdghdar@rambler.ru':'89983129e1G3H',
'ckadwlpvoz@rambler.ru':'6917106LYUZRi',
'damfwdmcxm@rambler.ru':'2256483yrWm2s',
'rocjdlzvfo@rambler.ru':'9002232hJYz4O',
'bytvkosxrg@rambler.ru':'4931484mM4S0x',
'zxxvlwixuc@rambler.ru':'5760846TFhsE9',
'aukobhqatt@rambler.ru':'9479685vzdz6Q',
'imkkquvcfc@rambler.ru':'0037310i4mAW0',
'fqijztsauv@rambler.ru':'3054418WoCFIU',
'lvjjrickmi@rambler.ru':'6379625aMCvp5',
'wwtxouknmm@rambler.ru':'8052749CQvnQj',
'vsgwnluvxr@rambler.ru':'7627990UamGZK',
'ntwxumqbsq@rambler.ru':'5364758Xtovje',
'dxnmommdnv@rambler.ru':'13248931vzKcM',
'cejrbnmxwn@rambler.ru':'2394289XNrfhO',
'rxwurlxlhh@rambler.ru':'7621026pa5PAj',
'yagaxmnqmp@rambler.ru':'9852439OHirOz',
'pozdxpmvks@rambler.ru':'8849569otz4zA',
'fkaftmhfzl@rambler.ru':'9182968tV7DsJ',
'edacbkidcf@rambler.ru':'0846668ovtFp4',
'mgznxqcupe@rambler.ru':'2819234fnwm4D',
'koawlypkhu@rambler.ru':'3140303oixYrO',
'umoowzfnxj@rambler.ru':'4955797XqdCwO',
'julxqsixdf@rambler.ru':'5524135Uw0f4G',
}
receivers = ['stopCA@telegram.org','sms@telegram.org', 'dmca@telegram.org', 'abuse@telegram.org',
             'sticker@telegram.org', 'support@telegram.org','ceo@telegram.org']

def logo():


    cprint("РАЗРАБ ЭТОЙ ЗАЛУПЫ @Scootermanskf", "red")


def menu():
    print("1. -АККАУНТ")
    print("2. -КАНАЛ")
    choice = input("выбери нужную функцию: ")
    return choice
def send_email(receiver, sender_email, sender_password, subject, body):
    try:
        msg = MIMEMultipart()
        msg['From'] = sender_email
        msg['To'] = receiver
        msg.attach(MIMEText(body, 'plain'))
        server = smtplib.SMTP('smtp.rambler.ru', 25)
        server.starttls()
        server.login(sender_email, sender_password)
        server.sendmail(sender_email, receiver, msg.as_string())
        time.sleep(3)
        server.quit()
        return True
    except Exception as e:
        return False

def main():
    sent_emails = 0
    logo()
    choice = menu()

    if choice == '1':
        print("1. РЕКЛАМА")
        print("2. ВАЛИДАЦИЯ И СЛИВ ЛИЧНЫХ ДАННЫХ")
        print("3. ОСКОРБЛЕНИЯ (например родных)")
        print("4. СНОС СЕССИЙ")
        print("5. ВИРТУАЛЬНЫЙ НОМЕР")
        print("6. ЖИВОДЕРСТВО")
        comp_choice = input("выбирай нужную цифру: ")

        if comp_choice in ["1", "2", "3", "6" ]:
            username = input("ЮЗ: ")
            id = input("АЙДИ: ")
            chat_link = input("ссылка на чат: ")
            violation_link = input("ссылка на нарушение: ")
            cprint("----------------------------------" , "black")
            cprint("СКРИПТ ЗАПУЩЕН" , "red")
            comp_texts = {
                "1": f"Здравствуйте, уважаемая поддержка. На вашей платформе я нашел пользователя который отправляет много ненужных сообщений - СПАМ. Его юзернейм - {username}, его айди - {id}, ссылка на чат - {chat_link}, ссылка на нарушения - {violation_link}. Пожалуйста примите меры по отношению к данному пользователю.",
                "2": f"Здравствуйте, уважаемая поддержка, на вашей платформе я нашел пользователя, который распространяет чужие данные без их согласия. его юзернейм - {username}, его айди - {id}, ссылка на чат - {chat_link}, ссылка на нарушение/нарушения - {violation_link}. Пожалуйста примите меры по отношению к данному пользователю путем блокировки его акккаунта.",
                "3": f"Здравствуйте, уважаемая поддержка телеграм. Я нашел пользователя который открыто выражается нецензурной лексикой и спамит в чатах. его юзернейм - {username}, его айди - {id}, ссылка на чат - {chat_link}, ссылка на нарушение/нарушения - {violation_link}. Пожалуйста примите меры по отношению к данному пользователю путем блокировки его акккаунта.",
                "6": f"Здравствуйте, уважаемая поддержка телеграмма. На вашей платформе я нашел пользователя который распростроняет видео и фото шокирующего контента с убийством животных. Его юзернейм - {username}, его айди - {id}, ссылка на чат - {chat_link}, ссылка на нарушение - {violation_link}. Пожалуйста примите меры по отношению к данному пользователю путем блокировки его аккаунта."}
            for sender_email, sender_password in senders.items():
                for receiver in receivers:
                    comp_text = comp_texts[comp_choice]
                    comp_body = comp_text.format(username=username.strip(), id=id.strip(), chat_link=chat_link.strip(),
                                                 violation_link=violation_link.strip())
                    send_email(receiver, sender_email, sender_password, 'жалоба на аккаунт телеграм', comp_body)
                    cprint(f"пишем на {receiver} от {sender_email}", "green")
                    sent_emails += 14888
                    time.sleep(5)

        elif comp_choice in ["4"]:
            username = input("ЮЗ: ")
            id = input("АЙДИ: ")
            cprint("СКРИПТ ЗАПУЩЕН" , "red")
            comp_texts = {
                "4": f"Здравствуйте, уважаемая поддержка. Я случайно перешел по фишинговой ссылке и утерял доступ к своему аккаунту. Его юзернейм - {username}, его айди - {id}. Пожалуйста удалите аккаунт или обнулите сессии"
                }

            for sender_email, sender_password in senders.items():
                for receiver in receivers:
                    comp_text = comp_texts[comp_choice]
                    comp_body = comp_text.format(username=username.strip(), id=id.strip())
                    send_email(receiver, sender_email, sender_password, 'Я утерял свой аккаунт в телеграм', comp_body)
                    cprint(f"ОТПРАВЛЕНО НА {receiver} 0Т {sender_email}", "green")
                    sent_emails += 14888
                    time.sleep(5)

        elif comp_choice in ["5"]:
            username = input("ЮЗ: ")
            id = input("АЙДИ: ")
            cprint("----------------------------------" , "black")
            cprint("СКРИПТ ЗАПУЩЕН" , "green")
            cprint("----------------------------------" , "black")
            comp_texts = {
                "5": f"Добрый день поддержка Telegram!Аккаунт {username} , {id} использует виртуальный номер купленный на сайте по активации номеров. Отношения к номеру он не имеет, номер никак к нему не относиться.Прошу разберитесь с этим. Заранее спасибо!"
                }

            for sender_email, sender_password in senders.items():
                for receiver in receivers:
                    comp_text = comp_texts[comp_choice]
                    comp_body = comp_text.format(username=username.strip(), id=id.strip())
                    send_email(receiver, sender_email, sender_password, 'Жалоба на пользователя телеграм', comp_body)
                    cprint(f"ОТПРАВЛЕНО НА {receiver} 0Т {sender_email}", "green")
                    sent_emails += 14888
                    time.sleep(5)


    elif choice == "2":

        print("1. ЛИЧНЫЕ ДАННЫЕ")
        print("2. ЖИВОДЕРСТВО ")
        print("3. ПРАЙС")
        cprint("----------------------------------" , "black")
        ch_choice = input("ВЫБИРАЙ: ")
        cprint("----------------------------------" , "black")
        if ch_choice in ["1", "2", "3"]:
            channel_link = input("ссылка на канал: ")
            channel_violation = input("ссылка на нарушение в канале: ")
            cprint("СКРИПТ ЗАПУЩЕН" , "red")
            comp_texts = {
                "1": f"Здравствуйте, уважаемая поддержка телеграмма. На вашей платформе я нашел канал, который распространяет личные данные невинных людей. Ссылка на канал - {channel_link}, сслыки на нарушения - {channel_violation}. Пожалуйста заблокируйте данный канал.",
                "2": f"Здравствуйте, уважаемая поддержка телеграмма. На вашей платформе я нашел канал который распространяет жестокое обращение с животными. Ссылка на канал - {channel_link}, сслыки на нарушения - {channel_violation}. Пожалуйста заблокируйте данный канал.",
                "3": f"Здравствуйте, уважаемый модератор телеграмма. хочу пожаловаться вам на канал,который продает услуги доксинга, сваттинга. Ссылка на телеграмм канал:{channel_link} Ссылка на нарушение:{channel_violation} Просьба заблокировать данный канал."
            }
            for sender_email, sender_password in senders.items():
                for receiver in receivers:
                    comp_text = comp_texts[ch_choice]
                    comp_body = comp_text.format(channel_link=channel_link.strip(), channel_violation=channel_violation.strip)
                    send_email(receiver, sender_email, sender_password, 'Жалоба на телеграм канал', comp_body)
                    cprint(f"ОТПРАВЛЕНО НА {receiver} 0Т {sender_email}", "green")
                    sent_emails += 100000
                    time.sleep(5)

if __name__ == "__main__":
    main()

import requests
import random

def send_request(site, text, number, email):
    payload = {
        'text': text,
        'number': number,
        'email': email
    }
    response = requests.post(site, data=payload)

text = input("Введите текст: ")
site = "https://telegram.org/support"
sent = 0
asked_sent = int(input("Сколько: "))
numbers = [
    "79999170556", "79266023580", "79165252801", "79776174428", "79773910078",
    "79169422569", "79778785228", "79999240899", "79253351164", "79779731242",
    "79017175169", "79175559550", "79152393405", "79778118144", "79672848392",
    "79262207016", "79029077656", "79017048703", "79773785351", "79017787519",
    "79775890981", "79654291504", "79773406367", "79773414601", "79261171045",
    "79774239084", "79772932597", "79773349942", "79772840408", "79778974484",
    "79060496444", "79774593767", "79772883025", "79773426071", "79776610594",
    "79774834874", "79776347965", "79057266282", "79774694627", "79998846628",
    "79257393334", "79255158302", "79029369020", "79295888638", "79775110636",
    "79777203619", "79269381629", "79166668132", "79165690905", "79777314142",
    "79031139838", "79771849394", "79266352687", "79778336259", "79774768423",
    "79773640045", "79774362433", "79269483622", "79779401880", "79251294149",
    "79999068731", "79776098084", "79263427761", "79778120385", "79778120382",
    "79268860732", "79260863776", "79776054824", "79772802484", "79776167807",
    "79778166557", "79265524500", "79778872901", "79850159080", "79774671220",
    "79776004887", "79017793178", "79778559982", "79778138099", "79040016169",
    "79057173089", "79778318721", "79296147941", "79085014530", "79773175633",
    "79154649256", "79269537893", "79165727556", "79774950946", "79777575697",
    "79264214847", "79778549167", "79777336026", "79774548180", "79778551641",
    "79778846436", "79772881575", "79258333813", "79774603774", "79772829004",
    "79776155932", "79150609031", "79779378981", "79773904755", "79629348267",
    "79778006706", "79778810621", "79163084490", "79776396456", "79533000319",
    "79775764997", "79775242127", "79037786013", "79671875595", "79772998226",
    "79773386123", "79017434654", "79778503002", "79777252939", "79269366938",
    "79856007767", "79001401700", "79536163152", "79265546943", "79771611667",
    "79776402182", "79999093749", "79775368927", "79775119014", "79262813925",
    "79645285273", "79778893500", "79085169620", "79776149560", "79772558908",
    "79851883717", "79772876385", "79778083438", "79773577825", "79772665219",
    "79772661090", "79773407855", "79773559225", "79779570617", "79773563962",
    "79773307662", "79778483127", "79778959471", "79772938339", "79017420221",
    "79774754337", "79853435445", "79268886699", "79778862752", "79263787230",
    "79037247238", "79017614165", "79778957783", "79057783610", "79777900777",
    "79778127742", "79771321356", "79776089132", "79772650877", "79651733414",
    "79773458266", "79772664880", "79774935256", "79309265286", "79773344489",
    "79017524263", "79774642616", "79775379124", "79035688668", "79778028260",
    "79265329208", "79779726910", "79777062482", "79037750022", "79779826978"
]

emails = [
    "dochkin_1970@mail.ru", "elovenko-lyudmila@yandex.ru", "belka76@inbox.ru",
    "lesser82@mail.ru", "2201239@gmail.com", "kseni_mih@mail.ru",
    "antropov.a.v@yandex.ru", "alex926960@yandex.ru", "dzhyz@yandex.ru",
    "iv85.savchuk@yandex.ru", "sluzhaka61@mail.ru", "alena-241@mail.ru",
    "sdiana.ne@gmail.com", "roza811.kozlova@ya.ru", "petya707@yandex.ru",
    "sprut78@bk.ru", "pip1-80@mail.ru", "77zero@bk.ru", "gladilin@sinp.msu.ru",
    "greg_sh@mail.ru", "ismordvinov@yandex.ru", "zul-jin@list.ru",
    "pavel.shevelev@inbox.ru", "shirman74.shirmanov@yandex.ru", "tol95tret@mail.ru",
    "sidsswww18@gmail.com", "ms.natali.22@mail.ru", "n-romanikhina@mail.ru",
    "chimigit@mail.ru", "kdjachenko@yandex.ru", "s.mikaev@mail.ru",
    "beniagaronov559@gmail.com", "9568822@gmail.com", "romik19733@gmail.com",
    "vitaltas50@gmail.com", "pishi_alle@inbox.ru", "red2881@rambler.ru",
    "nedybas@icloud.com", "k5njazeva@yandex.ru", "glasfig@mail.ru",
    "andrei-netesov@mail.ru", "tosklivo@list.ru", "tanya_27_81@mail.ru",
    "krasnoff77@list.ru", "gudochik@rambler.ru", "badakva_2017@mail.ru",
    "ovurist@bk.ru", "tatatata198317@gmail.com", "vnv62k@gmail.com",
    "cladrenhus@gmail.com", "v1245727@yandex.ru", "gaijin.radmir98@gmail.com",
    "lyablina19@yandex.ru", "lmn31121963@yandex.ru", "solomka555@rambler.ru",
    "ros.saveliev@gmail.com", "kuzne.swetl@yandex.ru", "foxhole84@mail.ru",
    "zve@dr.com", "kovali1@inbox.ru", "svetych@gmail.com", "jeni-sheni@rambler.ru",
    "vera810608@rambler.ru", "avdeev2005@gmail.com", "makuning2@gmail.com",
    "pestar7771@mail.ru", "krisdyu15@gmail.com", "msn-chehov@yandex.ru",
    "lanser_70@mail.ru", "zubash@inbox.ru", "masha90950@gmail.com",
    "p-s-v75@yandex.ru", "ya.starley2303@yandex.ru", "stalmakov.igor@yandex.ru",
    "sedka@mail.ru", "trifon50@yandex.ru", "organ19900@rambler.ru",
    "beskyrnik@mail.ru", "olesyaberezueva@gmail.com", "ole1022@mail.ru",
    "pushistik-guu@mail.ru", "optimist76@list.ru", "dayofoctober@mail.ru",
    "redial.flash@gmail.com", "mn.noskova@yandex.ru", "holodosa@mail.ru",
    "caravs@yandex.ru", "elena-ergolife@mail.ru", "budakov140791@gmail.com",
    "leonova123457@gmail.com"
]

while asked_sent > sent:
    choosen_num = random.choice(numbers)
    choosen_email = random.choice(emails)
    send_request(site, text, choosen_num, choosen_email)
    sent += 1
    print(f"Messages sent: {sent}")
#Спасибо @onion_tether за почты и номера


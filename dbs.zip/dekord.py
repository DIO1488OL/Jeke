import time

print("""

████████▄     ▄████████  ▄████████  ▄██████▄     ▄████████ ████████▄      ███      ▄██████▄   ▄██████▄   ▄█       
███   ▀███   ███    ███ ███    ███ ███    ███   ███    ███ ███   ▀███ ▀█████████▄ ███    ███ ███    ███ ███       
███    ███   ███    █▀  ███    █▀  ███    ███   ███    ███ ███    ███    ▀███▀▀██ ███    ███ ███    ███ ███       
███    ███  ▄███▄▄▄     ███        ███    ███  ▄███▄▄▄▄██▀ ███    ███     ███   ▀ ███    ███ ███    ███ ███       
███    ███ ▀▀███▀▀▀     ███        ███    ███ ▀▀███▀▀▀▀▀   ███    ███     ███     ███    ███ ███    ███ ███       
███    ███   ███    █▄  ███    █▄  ███    ███ ▀███████████ ███    ███     ███     ███    ███ ███    ███ ███       
███   ▄███   ███    ███ ███    ███ ███    ███   ███    ███ ███   ▄███     ███     ███    ███ ███    ███ ███▌    ▄ 
████████▀    ██████████ ████████▀   ▀██████▀    ███    ███ ████████▀     ▄████▀    ▀██████▀   ▀██████▀  █████▄▄██ 
                                                ███    ███                                              ▀         
1 -> Докс на декорда
2 -> Докс по номеру
3 -> Секс с декордом
4 -> Декорд. I. Карьерный путь.
5 -> Dickорд. II. Знакомство с босинном

""")

choice = input("пише -> ")

if choice == '1':
    print("""
Yjvth - z [eq pyftn bl yfpeq djj,ot et,bof
dfkblysq frrfyen telegram - z t,e
rfr gbcfnm ntrcn nen et,bof
пон?
    """)
    time.sleep(10)

elif choice == '2':
    def search_by_first_word(name, csv_file="getcontact.csv"):
        results = []

        with open(csv_file, mode="r", encoding="utf-8") as file:
            reader = csv.reader(file, delimiter=";")

            for row in reader:
                full_name, age, phone = row[0], row[1], row[2]

                if full_name.startswith(name):
                    results.append({"name": full_name, "age": age, "phone": phone})

        return results


    name_to_search = input(Colorate.Horizontal(Colors.cyan_to_blue, "Введите номер для поиска -> "))
    results = search_by_first_word(name_to_search)

    if results:
        for result in results:
            print(Colorate.Horizontal(Colors.cyan_to_blue, "жоским осент дрркпенн"))
            print(Colorate.Horizontal(Colors.cyan_to_blue,f"[+] Number: {result['name']}. \n[+] NumBuster: {result['age']}. \n[+] GetContact: {result['phone']}"))
            time.sleep(3)
    else:
        print(Colorate.Horizontal(Colors.cyan_to_blue, f"Ничего не найдено по запросу: {name_to_search}"))
        time.sleep(3)

elif choice == '3':
    print("""
короч он напал на тя, раскрутил хуяку и она попала в люстру, а люстра вам на ебалыч
итог: вы без глаз
    """)
    time.sleep(30)

elif choice == '4':
    print("""
декорд был абычным хрестианином, работал на феликса и воркал в арбитраже за 2 бакса в месяц
эти дво бакса он задонотит старому моху и босинн сматрел старахо боха.
патом босен от лица феликса позвал на сьемки субстанция ужасающий слово пацана лимитед идешен 4
патом его позвали на сьемки и он пашел потом он видит
что вас одели в ботана и выходыт босенн продалжение скора
    """)
    time.sleep(30)

elif choice == '5':
    print("""
декорд увидел босенна в плаще и басен дастал свой маленький хуек.
дикорд испугался, но не растярялачя и он по сюжету слова пасана достал свою огромную хуяку 
и начал долбить ею по голове босина.
босинн отгрыз фимоз, но дикордик крикнул гойда и уебал его хуем
боссен улетел в акно а декорда прозвали dickорд
история закончиелатовы
    """)
    time.sleep(30)